#!/bin/sh
./node/bin/node src/www