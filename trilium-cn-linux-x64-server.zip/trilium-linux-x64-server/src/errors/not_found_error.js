class NotFoundError {
    constructor(message) {
        this.message = message;
    }
}

module.exports = NotFoundError;