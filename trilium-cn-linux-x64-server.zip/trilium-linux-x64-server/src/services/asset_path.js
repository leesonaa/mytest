const packageJson = require('../../package.json');

module.exports = `assets/v${packageJson.version}`;
