const utils = require('./utils');

const instanceId = utils.randomString(12);

module.exports = instanceId;
