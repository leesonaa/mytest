module.exports = {
    SHARE_ROOT_NOTE_ID: '_share'
}
